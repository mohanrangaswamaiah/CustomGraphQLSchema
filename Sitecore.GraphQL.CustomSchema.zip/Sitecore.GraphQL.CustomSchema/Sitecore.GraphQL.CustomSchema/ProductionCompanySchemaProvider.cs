﻿using GraphQL.Types;
using Sitecore.Services.GraphQL.Schemas;
using System.Collections.Generic;

namespace Sitecore.GraphQL.CustomSchema
{
	public class ProductionCompanySchemaProvider : SchemaProviderBase
	{
		public override IEnumerable<FieldType> CreateRootQueries()
		{
			yield return new CompanyQuery();
		}
	}
}
