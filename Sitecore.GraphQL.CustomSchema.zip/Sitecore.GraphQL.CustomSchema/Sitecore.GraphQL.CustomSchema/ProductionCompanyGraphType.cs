﻿using GraphQL.Types;

namespace Sitecore.GraphQL.CustomSchema
{
	// because this graph type is referred to by the return type in the FieldType above, it is automatically
	// registered with the schema. For implied types (e.g. interface implementations) you need to override CreateGraphTypes() and
	// manually tell the schema they exist (because no graph type directly refers to those types)

	public class ProductionCompanyGraphType : ObjectGraphType<ProductionCompany>
	{
		public ProductionCompanyGraphType()
		{
			// graph type names must be unique within a schema, so if defining a multiple-schema-provider
			// endpoint, ensure that you don't have name collisions between schema providers.
			Name = "ProductionCompany";
			Field<NonNullGraphType<StringGraphType>>("id", resolve: context => context.Source.Id);
			Field<NonNullGraphType<StringGraphType>>("name", resolve: context => context.Source.Name);
			Field<NonNullGraphType<StringGraphType>>("logo_path", resolve: context => context.Source.LogoPath);
			Field<NonNullGraphType<StringGraphType>>("origin_country", resolve: context => context.Source.OriginCountry);
		}
	}
}
