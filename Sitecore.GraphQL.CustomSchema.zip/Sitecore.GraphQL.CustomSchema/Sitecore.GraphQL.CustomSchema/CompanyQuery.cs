﻿using GraphQL.Types;
using Sitecore.Services.GraphQL.Schemas;

namespace Sitecore.GraphQL.CustomSchema
{

	/// Teaches GraphQL how to resolve the `Company` root field.
	/// RootFieldType means this root field maps a `ProductionCompany` domain object into the `ProductionCompanyGraphType` graph type object.
	public class CompanyQuery : RootFieldType<ProductionCompanyGraphType, ProductionCompany>
	{
		public CompanyQuery() : base(name: "company", description: "Gets the production company details")
		{

		}

		protected override ProductionCompany Resolve(ResolveFieldContext context)
		{
			// this is the object the resolver maps onto the graph type
			// (see ProductionCompanyGraphType below). This is your own domain object, not GraphQL-specific.
			return new ProductionCompany
			{
				Id = 123,
				Name = "Mindtree Ltd an L&T Company",
				LogoPath = "c://abc/xyz/logo.png",
				OriginCountry = "Mindtree Ltd"
			};
		}
	}
}
